var searchData=
[
  ['k_5ffall_30',['k_fall',['../structrate__limiter__s.html#a63994a23bf12f5fe51113bd0595f9790',1,'rate_limiter_s']]],
  ['k_5frise_31',['k_rise',['../structrate__limiter__s.html#a468ebf0aab2c9983ce1e81a36ed254af',1,'rate_limiter_s']]]
];
