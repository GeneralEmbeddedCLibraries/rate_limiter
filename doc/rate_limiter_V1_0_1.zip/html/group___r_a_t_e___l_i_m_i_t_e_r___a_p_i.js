var group___r_a_t_e___l_i_m_i_t_e_r___a_p_i =
[
    [ "RATE_LIMITER_VER_DEVELOP", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#gace5704584a1286c1b99fe7a62c91fc54", null ],
    [ "RATE_LIMITER_VER_MAJOR", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#ga9e8f0572f93a2345f1ef907c06b9583e", null ],
    [ "RATE_LIMITER_VER_MINOR", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#ga6b748aebdd1a163c162539b0c9fbb1e5", null ],
    [ "p_rate_limiter_t", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#gac3cfe10ee43a935494e8c0dfad1d0b7f", null ],
    [ "rate_limiter_status_t", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#ga78534cfeb69eb64f5b681dd5097a731b", [
      [ "eRATE_LIMITER_OK", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#gga78534cfeb69eb64f5b681dd5097a731bad8839ee7bea2a548ad5d1f7097756d39", null ],
      [ "eRATE_LIMITER_ERROR", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#gga78534cfeb69eb64f5b681dd5097a731ba8a5b86c4422bf86d17be21f568d9a549", null ]
    ] ],
    [ "rate_limiter_change_rate", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#ga47dcf40f9789b0d7fbba6e26476ea476", null ],
    [ "rate_limiter_init", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#ga1cd53c34e2117251f6a63d411b3149e8", null ],
    [ "rate_limiter_is_init", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#gac70c113e82806b1c23930bb7a89e2b8e", null ],
    [ "rate_limiter_update", "group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#ga3b74895ced34b3909cac08c718d759db", null ]
];