var group___r_a_t_e___l_i_m_i_t_e_r =
[
    [ "rate_limiter_s", "structrate__limiter__s.html", [
      [ "dt", "structrate__limiter__s.html#a17bf26d642e43de21217ef6a444f9f2d", null ],
      [ "is_init", "structrate__limiter__s.html#a6361d3a658402665a95a489f5e4d33ae", null ],
      [ "k_fall", "structrate__limiter__s.html#a63994a23bf12f5fe51113bd0595f9790", null ],
      [ "k_rise", "structrate__limiter__s.html#a468ebf0aab2c9983ce1e81a36ed254af", null ],
      [ "x_prev", "structrate__limiter__s.html#a074a87a627297d700b7d5303fd559eb3", null ]
    ] ],
    [ "rate_limiter_t", "group___r_a_t_e___l_i_m_i_t_e_r.html#ga804a0993319f4de566ed98c0e4692345", null ],
    [ "rate_limiter_calc_rate_factor", "group___r_a_t_e___l_i_m_i_t_e_r.html#gad677fc015da4681bb6ec2476975c208e", null ]
];