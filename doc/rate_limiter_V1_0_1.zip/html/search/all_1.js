var searchData=
[
  ['erate_5flimiter_5ferror_1',['eRATE_LIMITER_ERROR',['../group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#gga78534cfeb69eb64f5b681dd5097a731ba8a5b86c4422bf86d17be21f568d9a549',1,'rate_limiter.h']]],
  ['erate_5flimiter_5fok_2',['eRATE_LIMITER_OK',['../group___r_a_t_e___l_i_m_i_t_e_r___a_p_i.html#gga78534cfeb69eb64f5b681dd5097a731bad8839ee7bea2a548ad5d1f7097756d39',1,'rate_limiter.h']]]
];
